import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-dallas',
  templateUrl: './dallas.component.html',
  styleUrls: ['./dallas.component.css']
})

export class DallasComponent implements OnInit {
  dallas:any;

constructor(
  private _httpService: HttpService,
  private _route: ActivatedRoute,
  private _router: Router
) {
  this.dallas;
}

  ngOnInit() {
    this.getDallas();
  }

  getDallas() {
    this._httpService.serviceGetDallas().subscribe(data=>{
      console.log('Component reached: ', data);
      this.dallas = data;
      console.log(this.dallas);
    })
  }

}
