import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-chicago',
  templateUrl: './chicago.component.html',
  styleUrls: ['./chicago.component.css']
})

export class ChicagoComponent implements OnInit {
  chicago:any;

constructor(
  private _httpService: HttpService,
  private _route: ActivatedRoute,
  private _router: Router
) {
  this.chicago;
}

  ngOnInit() {
    this.getChicago();
  }

  getChicago() {
    this._httpService.serviceGetChicago().subscribe(data=>{
      console.log('Component reached: ', data);
      this.chicago = data;
      console.log(this.chicago);
    })
  }

}
