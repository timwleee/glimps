import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()

export class HttpService {
  data:any;

  constructor(private _http: HttpClient) { 
  }
  
  serviceGetChicago(){
    console.log('Service ');
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=Chicago&APPID=c22231fe138cd14631dd69760876c6de');
  }

  serviceGetDallas(){
    console.log('Service ');
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=Dallas&APPID=c22231fe138cd14631dd69760876c6de');
  }




}
